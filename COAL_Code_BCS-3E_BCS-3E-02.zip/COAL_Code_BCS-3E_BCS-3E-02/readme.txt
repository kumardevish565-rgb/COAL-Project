SMART TRAFFIC GRID SIMULATION - README
====================================

Overview:

This project simulates a four-way intersection using a 32-bit x86 MASM
backend (TrafficLogic.asm) paired with a C++/Raylib graphical frontend
(main.cpp), exporting session statistics to traffic.txt via Win32 APIs.

Requirements:

- Windows (x86)
- Visual Studio with "Desktop development with C++" (includes MSVC and MASM ml.exe)
- raylib library (32-bit x86 headers and raylib.lib)
- Standard Windows libraries (kernel32.lib, user32.lib, gdi32.lib, winmm.lib)

Setup & Build Instructions (Visual Studio):

1. Open the solution/project in Visual Studio and set the configuration platform
   to Win32 (x86).
2. Enable MASM (.asm) build customization on the project so ml.exe assembles
   TrafficLogic.asm into an object file.
3. Add the raylib include directory under:
   Project Properties -> C/C++ -> General -> Additional Include Directories
4. Add the 32-bit raylib library directory under:
   Project Properties -> Linker -> General -> Additional Library Directories
5. Add raylib.lib (and required Win32 libraries if not already linked) under:
   Project Properties -> Linker -> Input -> Additional Dependencies
6. Build the solution (Ctrl+Shift+B) to link TrafficLogic.obj and main.obj.

Running the Program:

- Run the compiled executable from Visual Studio (F5 / Ctrl+F5) or directly
  from the output folder (ensure raylib.dll is next to the .exe if using a
  DLL build of raylib).
- Use the on-screen controls or keyboard shortcuts (such as N/E/S/W to add
  vehicles, SPACE to step a tick, and ESC / Save & Exit) to control the
  simulation.
- Exiting / saving generates or updates traffic.txt in the working directory
  with simulation totals, peak queue lengths, and tick timestamps.